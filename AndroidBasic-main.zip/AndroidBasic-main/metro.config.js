module.exports = {
    resolver: {
      sourceExts: ['jsx', 'js', 'ts', 'tsx','cs'], // Add other extensions as needed
    },
    // Other configurations...
  };
  